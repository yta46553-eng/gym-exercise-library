package com.abdullah.gymexerciselibrary

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray

private val Ink = Color(0xFF17211D)
private val Green = Color(0xFFB7F36B)
private val Canvas = Color(0xFFF5F6F0)
private val Muted = Color(0xFF69736D)
private val White = Color(0xFFFFFFFF)

data class Exercise(
    val id: String, val muscle: String, val subgroup: String,
    val number: Int, val name: String, val target: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { GymApp() }
    }
}

@Composable
fun GymApp() {
    val context = LocalContext.current
    val exercises = remember {
        val text = context.assets.open("exercises.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(text)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Exercise(o.getString("id"), o.getString("muscle"), o.getString("subgroup"),
                o.getInt("number"), o.getString("name"), o.getString("target"))
        }
    }
    val prefs = remember { context.getSharedPreferences("gym_library", 0) }
    var favorites by remember {
        mutableStateOf(prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet())
    }
    var search by remember { mutableStateOf("") }
    var selectedMuscle by remember { mutableStateOf<String?>(null) }
    var selectedSubgroup by remember { mutableStateOf<String?>(null) }
    var selectedExercise by remember { mutableStateOf<Exercise?>(null) }
    var showFavorites by remember { mutableStateOf(false) }

    val muscles = listOf("Chest", "Back", "Shoulders", "Biceps", "Triceps", "Legs")
    val counts = exercises.groupingBy { it.muscle }.eachCount()
    val visible = exercises.filter { ex ->
        (selectedMuscle == null || ex.muscle == selectedMuscle) &&
        (selectedSubgroup == null || ex.subgroup == selectedSubgroup) &&
        (!showFavorites || favorites.contains(ex.id)) &&
        (search.isBlank() || ex.name.contains(search, true) ||
            ex.target.contains(search, true) || ex.muscle.contains(search, true) ||
            ex.subgroup.contains(search, true))
    }

    MaterialTheme(colorScheme = lightColorScheme(
        primary = Ink, onPrimary = White, secondary = Green,
        background = Canvas, surface = White, onSurface = Ink
    )) {
        Surface(Modifier.fillMaxSize(), color = Canvas) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().background(Ink).padding(horizontal = 20.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.FitnessCenter, null, tint = Green, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("GYM EXERCISE", color = White, fontWeight = FontWeight.Black, fontSize = 19.sp)
                        Text("LIBRARY  •  OFFLINE", color = Green, fontSize = 11.sp, letterSpacing = 2.sp)
                    }
                    IconButton(onClick = {
                        showFavorites = !showFavorites
                        selectedMuscle = null; selectedSubgroup = null; selectedExercise = null
                    }) {
                        Icon(if (showFavorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            "Favorites", tint = if (showFavorites) Green else White)
                    }
                }
                if (selectedExercise != null) {
                    ExerciseDetail(selectedExercise!!, favorites.contains(selectedExercise!!.id),
                        { selectedExercise = null }, {
                            val next = favorites.toMutableSet()
                            if (!next.add(selectedExercise!!.id)) next.remove(selectedExercise!!.id)
                            favorites = next
                            prefs.edit().putStringSet("favorites", next).apply()
                        })
                } else {
                    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
                        Spacer(Modifier.height(16.dp))
                        Text(
                            when { showFavorites -> "TERI SAVED EXERCISES"; selectedMuscle != null -> selectedMuscle!!.uppercase(); else -> "APNI TRAINING LIBRARY" },
                            color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        Text(
                            if (selectedMuscle == null && !showFavorites) "Train smart. Track your moves." else "Exercise dhoondo aur details dekho.",
                            fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = Ink
                        )
                        Spacer(Modifier.height(14.dp))
                        SearchBox(search) { search = it }
                        Spacer(Modifier.height(12.dp))
                        if (selectedMuscle == null && !showFavorites && search.isBlank()) {
                            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                item {
                                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                        StatCard("650", "EXERCISE VARIATIONS", Modifier.weight(1f))
                                        StatCard("6", "MUSCLE GROUPS", Modifier.weight(1f))
                                    }
                                }
                                items(muscles) { muscle ->
                                    MuscleCard(muscle, counts[muscle] ?: 0) {
                                        selectedMuscle = muscle; selectedSubgroup = null; showFavorites = false
                                    }
                                }
                                item {
                                    Text("Tip: saari variations ek workout mein nahi karni. Apne plan ke mutabiq kuch exercises chuno.",
                                        color = Muted, fontSize = 12.sp, modifier = Modifier.padding(vertical = 10.dp))
                                }
                            }
                        } else {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                if (selectedMuscle != null || showFavorites) {
                                    TextButton(onClick = {
                                        selectedMuscle = null; selectedSubgroup = null; showFavorites = false; search = ""
                                    }) {
                                        Icon(Icons.Default.ArrowBack, null); Spacer(Modifier.width(4.dp)); Text("All muscles")
                                    }
                                }
                                Text("${visible.size} exercises", color = Muted, fontSize = 12.sp)
                            }
                            val groups = visible.map { it.subgroup }.distinct()
                            if (selectedMuscle != null && search.isBlank() && groups.size > 1) {
                                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    item {
                                        FilterChip(selected = selectedSubgroup == null,
                                            onClick = { selectedSubgroup = null }, label = { Text("All") })
                                    }
                                    items(groups) { group ->
                                        FilterChip(selected = selectedSubgroup == group,
                                            onClick = { selectedSubgroup = if (selectedSubgroup == group) null else group },
                                            label = { Text(group) })
                                    }
                                }
                            }
                            LazyColumn(
                                Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(8.dp),
                                contentPadding = PaddingValues(bottom = 24.dp)
                            ) {
                                items(visible, key = { it.id }) { ex ->
                                    ExerciseRow(ex, favorites.contains(ex.id), { selectedExercise = ex }) {
                                        val next = favorites.toMutableSet()
                                        if (!next.add(ex.id)) next.remove(ex.id)
                                        favorites = next
                                        prefs.edit().putStringSet("favorites", next).apply()
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SearchBox(search: String, onChange: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().background(White, RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Search, null, tint = Muted)
        Spacer(Modifier.width(8.dp))
        BasicTextField(
            value = search, onValueChange = onChange, modifier = Modifier.fillMaxWidth(), singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(color = Ink, fontSize = 15.sp),
            decorationBox = { inner ->
                if (search.isEmpty()) Text("Exercise ya muscle search karo...", color = Muted, fontSize = 14.sp)
                inner()
            }
        )
    }
}

@Composable
fun StatCard(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Green, RoundedCornerShape(18.dp)).padding(16.dp)) {
        Text(value, fontSize = 27.sp, fontWeight = FontWeight.Black, color = Ink)
        Text(label, fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Ink, letterSpacing = 0.5.sp)
    }
}

@Composable
fun MuscleCard(muscle: String, count: Int, onClick: () -> Unit) {
    val number = when (muscle) {
        "Chest" -> "01"; "Back" -> "02"; "Shoulders" -> "03"
        "Biceps" -> "04"; "Triceps" -> "05"; else -> "06"
    }
    Row(Modifier.fillMaxWidth().background(White, RoundedCornerShape(18.dp))
        .clickable(onClick = onClick).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).background(Green, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
            Text(number, fontWeight = FontWeight.Black, fontSize = 17.sp)
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(muscle, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Ink)
            Text("$count exercise variations", fontSize = 12.sp, color = Muted)
        }
        Text("›", fontSize = 30.sp, color = Muted)
    }
}

@Composable
fun ExerciseRow(exercise: Exercise, isFavorite: Boolean, onClick: () -> Unit, onFavorite: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(White, RoundedCornerShape(15.dp))
        .clickable(onClick = onClick).padding(start = 14.dp, top = 12.dp, bottom = 12.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(exercise.name, color = Ink, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Spacer(Modifier.height(4.dp))
            Text("${exercise.subgroup}  •  ${exercise.target}", color = Muted, fontSize = 11.sp)
        }
        IconButton(onClick = onFavorite) {
            Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                "Save exercise", tint = if (isFavorite) Color(0xFFD84A5B) else Muted)
        }
    }
}

@Composable
fun ExerciseDetail(exercise: Exercise, isFavorite: Boolean, onBack: () -> Unit, onFavorite: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        TextButton(onClick = onBack) {
            Icon(Icons.Default.ArrowBack, null); Spacer(Modifier.width(6.dp)); Text("Back to library")
        }
        Spacer(Modifier.height(20.dp))
        Box(Modifier.fillMaxWidth().background(Green, RoundedCornerShape(24.dp)).padding(22.dp)) {
            Column {
                Text(exercise.muscle.uppercase(), color = Ink, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                Spacer(Modifier.height(12.dp))
                Text(exercise.name, color = Ink, fontSize = 26.sp, fontWeight = FontWeight.Black, lineHeight = 31.sp)
                Spacer(Modifier.height(14.dp))
                Text("Exercise #${exercise.number}  •  ${exercise.subgroup}", color = Ink, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("TARGET MUSCLE / FOCUS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(6.dp))
        Text(exercise.target, color = Ink, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(18.dp))
        Text("TRAINING NOTE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        Spacer(Modifier.height(6.dp))
        Text("Controlled form ke saath karo. Apne level ke hisaab se weight aur range chuno; sharp pain ya badhta discomfort ho to ruk jao.",
            color = Ink, fontSize = 14.sp, lineHeight = 21.sp)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onFavorite, colors = ButtonDefaults.buttonColors(containerColor = Ink, contentColor = White),
            modifier = Modifier.fillMaxWidth()) {
            Icon(if (isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null)
            Spacer(Modifier.width(8.dp))
            Text(if (isFavorite) "Saved to Favorites" else "Save to Favorites")
        }
    }
}
